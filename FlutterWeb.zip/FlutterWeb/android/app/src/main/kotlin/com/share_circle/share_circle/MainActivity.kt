package com.share_circle.share_circle

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
